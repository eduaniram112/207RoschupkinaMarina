using System;
using System.IO;


public class Wizard : LegendaryHuman
{
    private Rank rank;

    public Rank WizardRank
    {
        get => rank;
    }

    public Wizard(string name, int healthPoints, int power, string rank) : base(name, healthPoints,
        power)
    {
        if (!Rank.TryParse(rank, out this.rank))
        {
            throw new ArgumentException($"Got unexpected rank value: {rank}");
        }
    }

    public enum Rank
    {
        Neophyte = 1,
        Adept,
        Charmer,
        Sorcerer,
        Master,
        Archmage
    }

    public override void Attack(LegendaryHuman enemy)
    {
        Console.WriteLine(this + " attacked " + enemy);
        enemy.HealthPoints -= (Power * (int)Math.Pow((int)rank, 1.5) + HealthPoints / 10);

        if (enemy.IsDead)
        {
            Console.WriteLine(enemy + " is dead.");
        }
    }

    public override string ToString()
    {
        return $"{WizardRank.ToString()} " + base.ToString();
    }
}