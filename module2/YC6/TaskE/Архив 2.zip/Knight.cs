using System;
using System.IO;

public class Knight : LegendaryHuman
{
    public string[] Equipment { get; set; }

    public Knight(string name, int healthPoints, int power, string[] equipment) : base(name, healthPoints, power)
    {
        if (equipment.Length == 0)
        {
            throw new ArgumentException("Not enough equipment.");
        }
        Equipment = equipment;
    }

    public override void Attack(LegendaryHuman enemy)
    {
        Console.WriteLine(this + " attacked " + enemy);
        enemy.HealthPoints -= Power + 10 * Equipment.Length;
        if (enemy.IsDead)
        {
            Console.WriteLine(enemy + " is dead.");
        }
    }
}